#!/bin/bash
set -euo pipefail
tmp="$(mktemp -d "$HOME/.rcc-expedition-slurm.XXXXXX")"
trap 'rm -rf "$tmp"' EXIT
cd "$tmp"
cat > job.sh <<'JOB'
#!/bin/bash
#SBATCH --job-name=rcc-expedition
#SBATCH --time=00:02:00
#SBATCH --mem=64M
#SBATCH --cpus-per-task=1
printf 'RCC_EXPEDITION_SLURM_OK
'
hostname
JOB
jobid="$(sbatch --parsable job.sh)"
echo "Job: $jobid"
for i in $(seq 1 45); do
  state="$(sacct -n -X -j "$jobid" --format=State -P 2>/dev/null | head -1 | cut -d'|' -f1 | awk '{print $1}')"
  case "$state" in
    COMPLETED)
      cat "slurm-${jobid}.out"
      echo RCC_EXPEDITION_RESULT=PASS
      exit 0 ;;
    FAILED|CANCELLED|TIMEOUT|OUT_OF_MEMORY|NODE_FAIL)
      echo "State: $state"
      echo RCC_EXPEDITION_RESULT=FAIL
      exit 1 ;;
  esac
  sleep 2
done
echo RCC_EXPEDITION_RESULT=FAIL
exit 1
