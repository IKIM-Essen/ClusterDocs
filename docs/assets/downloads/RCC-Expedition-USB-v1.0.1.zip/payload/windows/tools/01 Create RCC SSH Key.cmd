@echo off
setlocal
set "ROOT=%LOCALAPPDATA%\RCC Expedition"
set "KEY=%USERPROFILE%\.ssh\id_ikim"
cls
echo CREATE RCC SSH KEY
echo ==================
echo.
echo The private key stays on this PC.
echo Only the .pub file is registered.
echo.
echo Choose a passphrase when asked.
echo.
pause

where ssh-keygen.exe >nul 2>&1
if errorlevel 1 (
 echo OpenSSH Client is not installed.
 echo Return to the course.
 exit /b 1
)
if exist "%KEY%" (
 echo Key already exists. Nothing changed.
 exit /b 1
)
if not exist "%USERPROFILE%\.ssh" mkdir "%USERPROFILE%\.ssh"
ssh-keygen.exe -t ed25519 -a 100 -f "%KEY%"
echo.
echo Public key:
type "%KEY%.pub"
echo.
echo Never share:
echo %KEY%
call "%ROOT%\windows\tools\rcc-doctor.cmd" >nul 2>&1
start "" "%ROOT%\course\index.html"
endlocal
