@echo off
setlocal EnableExtensions
set "TOOLS=%~dp0"
for %%I in ("%TOOLS%\..\..\..") do set "USB_ROOT=%%~fI"
set "ROOT=%LOCALAPPDATA%\RCC Expedition"
for /f "usebackq delims=" %%D in (`powershell.exe -NoProfile -Command "[Environment]::GetFolderPath('Desktop')"`) do set "DESKTOP=%%D"

cls
echo RCC EXPEDITION
echo ==============
echo.
echo Local and datensparsam.
echo No monitoring. No telemetry.
echo.
echo Do not use hospital/clinical VPN
echo as an RCC connectivity shortcut.
echo.
echo Press any key to install.
echo Control-C cancels.
pause >nul

echo Checking release...
powershell.exe -NoProfile -Command "$root='%USB_ROOT%'; $ok=$true; Get-Content (Join-Path $root 'SHA256SUMS') | ForEach-Object { if($_ -match '^([0-9a-fA-F]{64})  (.+)$'){ $p=Join-Path $root $matches[2]; if(-not (Test-Path -LiteralPath $p)){ $ok=$false } elseif((Get-FileHash -Algorithm SHA256 -LiteralPath $p).Hash.ToLower() -ne $matches[1].ToLower()){ $ok=$false } } }; if(-not $ok){ exit 2 }"
if errorlevel 1 (
 echo Integrity check failed.
 exit /b 2
)
echo OK

echo Installing...
if exist "%ROOT%" rmdir /s /q "%ROOT%"
mkdir "%ROOT%" >nul
xcopy "%USB_ROOT%\payload\course" "%ROOT%\course\" /E /I /Y /Q >nul
xcopy "%USB_ROOT%\payload\windows" "%ROOT%\windows\" /E /I /Y /Q >nul

rem The private local copy is explicitly trusted after the user-started
rem integrity check. This does not disable SmartScreen globally.
powershell.exe -NoProfile -Command "Get-ChildItem -LiteralPath '%ROOT%' -Recurse -File | Unblock-File" >nul 2>&1

(
 echo @echo off
 echo call "%%LOCALAPPDATA%%\RCC Expedition\windows\tools\rcc-doctor.cmd" ^>nul 2^>^&1
 echo start "" "%%LOCALAPPDATA%%\RCC Expedition\course\index.html"
) > "%DESKTOP%\RCC Expedition.cmd"

if exist "%DESKTOP%\RCC Expedition Tools" rmdir /s /q "%DESKTOP%\RCC Expedition Tools"
mkdir "%DESKTOP%\RCC Expedition Tools" >nul
copy /Y "%ROOT%\windows\tools\01 Create RCC SSH Key.cmd" "%DESKTOP%\RCC Expedition Tools\" >nul
copy /Y "%ROOT%\windows\tools\02 Create Linux Practice.cmd" "%DESKTOP%\RCC Expedition Tools\" >nul
copy /Y "%ROOT%\windows\tools\03 Test RCC SSH.cmd" "%DESKTOP%\RCC Expedition Tools\" >nul
copy /Y "%ROOT%\windows\tools\04 Run First Slurm Mission.cmd" "%DESKTOP%\RCC Expedition Tools\" >nul
copy /Y "%ROOT%\windows\tools\99 Remove RCC Practice.cmd" "%DESKTOP%\RCC Expedition Tools\" >nul

call "%ROOT%\windows\tools\rcc-doctor.cmd" >nul 2>&1
start "" "%ROOT%\course\index.html"

echo.
echo Ready.
echo Course opened in your browser.
echo You may remove the USB.
endlocal
