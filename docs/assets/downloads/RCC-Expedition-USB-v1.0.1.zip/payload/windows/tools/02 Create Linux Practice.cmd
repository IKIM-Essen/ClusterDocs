@echo off
setlocal
set "ROOT=%LOCALAPPDATA%\RCC Expedition"
cls
echo LINUX PRACTICE
echo ==============
echo.
echo Creates tiny synthetic files
echo in your RCC home directory.
echo.
pause
ssh.exe shellhost "bash -s" < "%ROOT%\windows\tools\linux-practice.sh"
if errorlevel 1 (
 echo FAIL. Return to the course.
 exit /b 1
)
echo Practice files created.
echo Return to the course.
endlocal
