@echo off
setlocal EnableExtensions
set "ROOT=%LOCALAPPDATA%\RCC Expedition"
set "OUT=%ROOT%\course\generated\device-state.js"
set "STATE=%ROOT%\windows\state\rcc-state.cmd"
if not exist "%ROOT%\windows\state" mkdir "%ROOT%\windows\state" >nul

set "BUILD=0"
for /f "delims=" %%A in ('powershell.exe -NoProfile -Command "[Environment]::OSVersion.Version.Build"') do set "BUILD=%%A"
set "SUPPORTED=FAIL_UNSUPPORTED_WINDOWS"
if %BUILD% GEQ 22000 set "SUPPORTED=PASS"

set "ENCRYPTION=UNKNOWN"
for /f "delims=" %%A in ('powershell.exe -NoProfile -Command "try{$b=Get-BitLockerVolume -MountPoint $env:SystemDrive -ErrorAction Stop; if(([int]$b.ProtectionStatus -eq 1) -or ($b.ProtectionStatus -eq 'On')){'PASS'}else{'FAIL'}}catch{try{$v=Get-CimInstance -Namespace 'root/CIMV2/Security/MicrosoftVolumeEncryption' -ClassName Win32_EncryptableVolume -Filter ('DriveLetter='''+$env:SystemDrive+'''') -ErrorAction Stop; $r=Invoke-CimMethod -InputObject $v -MethodName GetProtectionStatus -ErrorAction Stop; if($r.ProtectionStatus -eq 1){'PASS'}else{'FAIL'}}catch{'UNKNOWN'}}"') do set "ENCRYPTION=%%A"

set "DEFENDER=UNKNOWN"
for /f "delims=" %%A in ('powershell.exe -NoProfile -Command "try{$m=Get-MpComputerStatus -ErrorAction Stop; if($m.AntivirusEnabled -and $m.RealTimeProtectionEnabled){'PASS'}else{'FAIL'}}catch{'UNKNOWN'}"') do set "DEFENDER=%%A"

set "FIREWALL=UNKNOWN"
for /f "delims=" %%A in ('powershell.exe -NoProfile -Command "try{$p=@(Get-NetFirewallProfile -ErrorAction Stop); if(@($p ^| Where-Object {$_.Enabled}).Count -eq $p.Count){'PASS'}else{'FAIL'}}catch{'UNKNOWN'}"') do set "FIREWALL=%%A"

set "SECUREBOOT=UNKNOWN"
for /f "delims=" %%A in ('powershell.exe -NoProfile -Command "try{if(Confirm-SecureBootUEFI -ErrorAction Stop){'PASS'}else{'FAIL'}}catch{'UNKNOWN'}"') do set "SECUREBOOT=%%A"

set "SSHCLIENT=FAIL_NOT_INSTALLED"
where ssh.exe >nul 2>&1 && where ssh-keygen.exe >nul 2>&1 && set "SSHCLIENT=PASS"

set "SSHKEY=NOT_SET"
if exist "%USERPROFILE%\.ssh\id_ikim" if exist "%USERPROFILE%\.ssh\id_ikim.pub" set "SSHKEY=PASS"

set "RCCSSH=NOT_TRIED"
set "RCCSLURM=NOT_TRIED"
if exist "%STATE%" call "%STATE%"

set "NOW=unknown"
for /f "delims=" %%A in ('powershell.exe -NoProfile -Command "(Get-Date).ToString('yyyy-MM-dd HH:mm:ss')"') do set "NOW=%%A"
set "CAPTION=Windows"
for /f "delims=" %%A in ('powershell.exe -NoProfile -Command "(Get-CimInstance Win32_OperatingSystem).Caption"') do set "CAPTION=%%A"

> "%OUT%" echo window.RCC_DEVICE_STATE = {
>>"%OUT%" echo  generated: "%NOW%",
>>"%OUT%" echo  platform: "windows",
>>"%OUT%" echo  version: "%CAPTION% build %BUILD%",
>>"%OUT%" echo  checks: {
>>"%OUT%" echo   supportedOS: "%SUPPORTED%",
>>"%OUT%" echo   diskEncryption: "%ENCRYPTION%",
>>"%OUT%" echo   platformSecurity: "WINDOWS_SECURITY",
>>"%OUT%" echo   defender: "%DEFENDER%",
>>"%OUT%" echo   firewall: "%FIREWALL%",
>>"%OUT%" echo   secureBoot: "%SECUREBOOT%",
>>"%OUT%" echo   sshClient: "%SSHCLIENT%",
>>"%OUT%" echo   sshKey: "%SSHKEY%",
>>"%OUT%" echo   rccSsh: "%RCCSSH%",
>>"%OUT%" echo   rccSlurm: "%RCCSLURM%"
>>"%OUT%" echo  }
>>"%OUT%" echo };
endlocal
