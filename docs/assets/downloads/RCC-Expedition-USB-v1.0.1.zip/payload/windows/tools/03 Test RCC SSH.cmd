@echo off
setlocal EnableExtensions
set "ROOT=%LOCALAPPDATA%\RCC Expedition"
set "STATE=%ROOT%\windows\state\rcc-state.cmd"
if not exist "%ROOT%\windows\state" mkdir "%ROOT%\windows\state" >nul
cls
echo TEST RCC SSH
echo ============
echo.
echo Runs one harmless fixed command
echo on the SSH host alias shellhost.
echo.
pause

set "OLD_SLURM=NOT_TRIED"
if exist "%STATE%" (
 call "%STATE%"
 set "OLD_SLURM=%RCCSLURM%"
)

set "RCCSSH=FAIL"
for /f "delims=" %%A in ('ssh.exe -o ConnectTimeout=15 shellhost "printf RCC_EXPEDITION_OK" 2^>nul') do (
 if "%%A"=="RCC_EXPEDITION_OK" set "RCCSSH=PASS"
)

> "%STATE%" echo set "RCCSSH=%RCCSSH%"
>>"%STATE%" echo set "RCCSLURM=%OLD_SLURM%"

echo %RCCSSH%
call "%ROOT%\windows\tools\rcc-doctor.cmd" >nul 2>&1
start "" "%ROOT%\course\index.html"
endlocal
