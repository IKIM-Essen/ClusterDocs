@echo off
echo Removing RCC Expedition practice files only.
ssh.exe shellhost "rm -rf ""$HOME/.rcc-expedition-practice"" ""$HOME""/.rcc-expedition-slurm.*"
echo Done.
