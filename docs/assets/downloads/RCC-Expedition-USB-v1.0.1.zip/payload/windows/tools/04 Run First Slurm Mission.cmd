@echo off
setlocal EnableExtensions
set "ROOT=%LOCALAPPDATA%\RCC Expedition"
set "STATE=%ROOT%\windows\state\rcc-state.cmd"
set "RESULT=%TEMP%\rcc-expedition-result-%RANDOM%.txt"
if not exist "%ROOT%\windows\state" mkdir "%ROOT%\windows\state" >nul
cls
echo FIRST SLURM JOB
echo ===============
echo.
echo Submits one tiny synthetic job.
echo Temporary files are removed.
echo.
pause

set "OLD_SSH=NOT_TRIED"
if exist "%STATE%" (
 call "%STATE%"
 set "OLD_SSH=%RCCSSH%"
)

ssh.exe shellhost "bash -s" < "%ROOT%\windows\tools\slurm-mission.sh" > "%RESULT%" 2>&1
type "%RESULT%"
set "RCCSLURM=FAIL"
findstr /C:"RCC_EXPEDITION_RESULT=PASS" "%RESULT%" >nul && set "RCCSLURM=PASS"
del /q "%RESULT%" >nul 2>&1

> "%STATE%" echo set "RCCSSH=%OLD_SSH%"
>>"%STATE%" echo set "RCCSLURM=%RCCSLURM%"

echo %RCCSLURM%
call "%ROOT%\windows\tools\rcc-doctor.cmd" >nul 2>&1
start "" "%ROOT%\course\index.html"
endlocal
