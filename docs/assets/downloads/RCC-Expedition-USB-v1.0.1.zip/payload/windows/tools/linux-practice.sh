#!/bin/bash
set -e
root="$HOME/.rcc-expedition-practice/mystery"
rm -rf "$HOME/.rcc-expedition-practice"
mkdir -p "$root/alpha" "$root/beta/deeper" "$root/gamma"
printf 'nothing here
' > "$root/alpha/readme.txt"
printf 'ACGTACGT
' > "$root/beta/data.txt"
printf 'sequence=GATTACA
' > "$root/beta/deeper/clue.txt"
printf 'almost=GATACA
' > "$root/gamma/near-miss.txt"
