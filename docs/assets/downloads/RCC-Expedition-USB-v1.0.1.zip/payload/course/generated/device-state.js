window.RCC_DEVICE_STATE = {
 generated: "not yet checked",
 platform: "unknown",
 version: "unknown",
 checks: {
  supportedOS: "UNKNOWN",
  diskEncryption: "UNKNOWN",
  platformSecurity: "UNKNOWN",
  defender: "UNKNOWN",
  firewall: "UNKNOWN",
  secureBoot: "UNKNOWN",
  sshClient: "UNKNOWN",
  sshKey: "NOT_SET",
  rccSsh: "NOT_TRIED",
  rccSlurm: "NOT_TRIED"
 }
};
