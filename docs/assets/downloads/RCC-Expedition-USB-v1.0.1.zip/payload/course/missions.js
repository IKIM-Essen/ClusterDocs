window.RCC_MISSIONS = [
  {
    "id": "arrival.privacy",
    "area": "Arrival",
    "title": "Datensparsam: this course stays local",
    "minutes": 3,
    "platforms": [
      "mac",
      "windows"
    ],
    "required": [],
    "summary": "No monitoring, analytics, learner server, or supervisor dashboard.",
    "lesson": "RCC Expedition is local by design.\n\nThere is no central learner account and no server receiving your progress. Mission state stays in this browser. Local readiness tools store only coarse PASS/WARN/FAIL/UNKNOWN values.\n\nThe browser application contains no analytics library and its Content Security Policy disables application network connections.\n\nExternal references open only after you click them. RCC is contacted only when you deliberately start an SSH exercise.\n\nNever put passwords, recovery keys, private SSH keys, or research data into this course.",
    "challenge": "Open the privacy panel and verify that you understand what remains local.",
    "hints": [],
    "mode": "manual"
  },
  {
    "id": "security.boundary",
    "area": "Security",
    "title": "Keep research and clinical network roles separate",
    "minutes": 10,
    "platforms": [
      "mac",
      "windows"
    ],
    "required": [
      "arrival.privacy"
    ],
    "summary": "Do not turn an unmanaged/research workstation into a clinical endpoint.",
    "lesson": "A research workstation used for RCC has a different security role from a managed clinical endpoint.\n\nDo not use hospital/clinical VPN as a route from a privately maintained or research workstation into the clinical network. Do not attach an unmanaged research laptop/desktop to clinical/internal networks merely because they are available.\n\nReachability itself changes risk. Browser sessions, mapped shares, caches, sync clients, temporary files, IDE extensions, logs, and background programs can move information without an intentional patient-data copy.\n\nUse an appropriately managed hospital endpoint for hospital-only clinical resources.\n\nFor ordinary Internet connectivity, use eduroam when eligible. Where locally provided, Stiftungsnetz may be a temporary/semi-official bootstrap Internet route; this course makes no undocumented claim about its isolation.\n\nRCC is reached through the documented Internet/SSH path, not through hospital VPN.",
    "challenge": "Explain why promising not to open patient data is not sufficient if an unmanaged workstation can directly reach clinical systems.",
    "hints": [
      "Think about cached sessions, mapped drives, browsers, sync tools, and background applications."
    ],
    "mode": "manual",
    "policy": true
  },
  {
    "id": "security.win11",
    "area": "Windows security",
    "title": "Use a supported Windows 11 system",
    "minutes": 6,
    "platforms": [
      "windows"
    ],
    "required": [
      "security.boundary"
    ],
    "summary": "Windows 10 is no longer an acceptable baseline for a new RCC workstation.",
    "lesson": "RCC Expedition expects Windows 11.\n\nMicrosoft ended normal free Windows 10 security updates in October 2025. A system that no longer receives normal security fixes should not become a new research workstation.\n\nOpen Settings → System → About and verify the version. Then run Windows Update.\n\nIf the local readiness panel reports UNSUPPORTED_WINDOWS, upgrade or replace the system before placing research credentials or data on it.",
    "challenge": "Reach Supported Windows = PASS and install current Windows updates.",
    "hints": [],
    "mode": "device",
    "deviceKey": "supportedOS",
    "external": [
      [
        "Microsoft: Windows Update",
        "https://support.microsoft.com/en-us/windows/deployment/updates-lifecycle/install-windows-updates"
      ]
    ]
  },
  {
    "id": "security.macos",
    "area": "Mac security",
    "title": "Start from a current, patched macOS",
    "minutes": 6,
    "platforms": [
      "mac"
    ],
    "required": [
      "security.boundary"
    ],
    "summary": "Install current stable macOS/security updates before research work accumulates.",
    "lesson": "Open Apple menu → System Settings → General → Software Update.\n\nInstall current stable system/security updates and enable automatic update options.\n\nDo not use beta OS releases on a production research workstation without a specific reason and recovery plan.",
    "challenge": "Install current stable macOS updates and enable automatic security/system updates.",
    "hints": [],
    "mode": "manual",
    "external": [
      [
        "Apple: Software Update settings",
        "https://support.apple.com/guide/mac-help/mchla7037245/mac"
      ]
    ]
  },
  {
    "id": "security.encrypt.win",
    "area": "Windows security",
    "title": "Encrypt the Windows system drive",
    "minutes": 10,
    "platforms": [
      "windows"
    ],
    "required": [
      "security.win11"
    ],
    "summary": "Use Device Encryption/BitLocker before research credentials and files accumulate.",
    "lesson": "Open Settings → Privacy & security → Device encryption when available.\n\nWindows Device Encryption uses BitLocker technology and may already be enabled. Windows Pro/Education/Enterprise also expose BitLocker Drive Encryption controls.\n\nDo not finish until you know where the recovery key is stored. Never paste the 48-digit recovery key into this course, chat, Git, or a shell script.\n\nIf encryption is unavailable, investigate rather than ignoring it.",
    "challenge": "Reach System encryption = PASS and know how you would recover the machine.",
    "hints": [
      "Device Encryption availability and full BitLocker management depend on hardware and Windows edition."
    ],
    "mode": "device",
    "deviceKey": "diskEncryption",
    "external": [
      [
        "Microsoft: Device Encryption",
        "https://support.microsoft.com/en-us/windows/security/encryption/device-encryption-in-windows"
      ],
      [
        "Microsoft: BitLocker overview",
        "https://support.microsoft.com/en-us/windows/security/encryption/bitlocker-overview"
      ],
      [
        "Microsoft: recovery key",
        "https://support.microsoft.com/en-us/windows/security/encryption/back-up-your-bitlocker-recovery-key"
      ]
    ]
  },
  {
    "id": "security.encrypt.mac",
    "area": "Mac security",
    "title": "Enable FileVault",
    "minutes": 8,
    "platforms": [
      "mac"
    ],
    "required": [
      "security.macos"
    ],
    "summary": "Protect data at rest before the Mac becomes a research workstation.",
    "lesson": "Open Apple menu → System Settings → Privacy & Security → FileVault and turn FileVault on.\n\nStore recovery material deliberately. Never paste it into this course, chat, email, Git, or shell commands.\n\nRe-open RCC Expedition from the Desktop launcher after encryption state changes.",
    "challenge": "Reach FileVault = PASS in the local readiness panel.",
    "hints": [],
    "mode": "device",
    "deviceKey": "diskEncryption",
    "external": [
      [
        "Apple: FileVault",
        "https://support.apple.com/guide/mac-help/protect-data-on-your-mac-with-filevault-mh11785/mac"
      ]
    ]
  },
  {
    "id": "security.windows-security",
    "area": "Windows security",
    "title": "Leave Windows Security protections on",
    "minutes": 10,
    "platforms": [
      "windows"
    ],
    "required": [
      "security.win11"
    ],
    "summary": "Defender, firewall, Secure Boot, and device security are baseline controls.",
    "lesson": "Open Windows Security.\n\nReview Virus & threat protection, Firewall & network protection, and Device security.\n\nDo not disable real-time malware protection because an installer is inconvenient. Keep the firewall enabled. Verify Secure Boot/device security when supported.\n\nIf Windows warns about downloaded software, investigate provenance rather than training yourself to bypass warnings.",
    "challenge": "Reach Defender = PASS and Firewall = PASS. Review Device security.",
    "hints": [],
    "mode": "manual",
    "external": [
      [
        "Microsoft: Windows Security",
        "https://support.microsoft.com/en-us/windows/security/windows-security/stay-protected-with-the-windows-security-app"
      ],
      [
        "Microsoft: Device security",
        "https://support.microsoft.com/en-us/windows/security/windows-security/device-security-in-the-windows-security-app"
      ]
    ]
  },
  {
    "id": "security.gatekeeper",
    "area": "Mac security",
    "title": "Keep Gatekeeper and safe installation habits",
    "minutes": 7,
    "platforms": [
      "mac"
    ],
    "required": [
      "security.macos"
    ],
    "summary": "Investigate security warnings instead of learning to bypass them.",
    "lesson": "Install software from authoritative sources.\n\nDo not disable Gatekeeper globally to make unidentified software run. If a genuine exception is required, verify provenance first and use the narrowest justified action.\n\nAvoid random download mirrors, driver tools, codec packs, and “cleaner” applications.",
    "challenge": "Reach Gatekeeper = PASS and identify authoritative sources for the tools you expect to install.",
    "hints": [],
    "mode": "device",
    "deviceKey": "platformSecurity"
  },
  {
    "id": "security.patching.win",
    "area": "Windows security",
    "title": "Patch Windows and applications continuously",
    "minutes": 8,
    "platforms": [
      "windows"
    ],
    "required": [
      "security.win11"
    ],
    "summary": "Patching is recurring maintenance, not a one-time onboarding task.",
    "lesson": "Open Settings → Windows Update → Check for updates.\n\nInstall security/quality updates and restart when required. Repeat until current. Do not leave updates paused indefinitely.\n\nApplications need updates too. Microsoft Store can update Store applications automatically; other applications may carry their own updater. Prefer maintained software and remove abandoned tools.",
    "challenge": "Run Windows Update now and verify automatic application updates are not deliberately disabled.",
    "hints": [
      "Schedule restarts instead of permanently suppressing updates."
    ],
    "mode": "manual",
    "external": [
      [
        "Microsoft: Windows Update FAQ",
        "https://support.microsoft.com/en-us/windows/deployment/updates-lifecycle/windows-update-faq"
      ],
      [
        "Microsoft: automatic app updates",
        "https://support.microsoft.com/en-us/windows/apps/turn-on-automatic-app-updates"
      ]
    ]
  },
  {
    "id": "security.patching.mac",
    "area": "Mac security",
    "title": "Keep macOS and applications patched",
    "minutes": 8,
    "platforms": [
      "mac"
    ],
    "required": [
      "security.macos"
    ],
    "summary": "Do not postpone security updates indefinitely because the laptop is busy.",
    "lesson": "Enable automatic macOS/security updates and install current stable updates.\n\nApplications also need maintenance. Use trusted distribution channels, allow reputable software to update, and remove abandoned applications/extensions.\n\nAn environment that only works on an obsolete unpatched laptop is a reproducibility problem too.",
    "challenge": "Verify automatic macOS/security updates and know how your browser/editor stays updated.",
    "hints": [],
    "mode": "manual",
    "external": [
      [
        "Apple: Software Update",
        "https://support.apple.com/guide/mac-help/mchla7037245/mac"
      ]
    ]
  },
  {
    "id": "security.lock",
    "area": "Workstation security",
    "title": "Use a personal account and lock the screen",
    "minutes": 5,
    "platforms": [
      "mac",
      "windows"
    ],
    "required": [
      "security.boundary"
    ],
    "summary": "An unattended logged-in workstation is an open session.",
    "lesson": "Use your own OS account. Do not share a generic lab login for research work.\n\nConfigure Windows Hello or Touch ID where available and require authentication promptly after screen lock.\n\nImmediate lock:\nWindows: Windows-L\nMac: Control-Command-Q\n\nDaily work should not require running every shell/application as administrator/root.",
    "challenge": "Lock the workstation now with the keyboard shortcut and unlock it normally.",
    "hints": [],
    "mode": "manual"
  },
  {
    "id": "security.passwords",
    "area": "Workstation security",
    "title": "Use a password manager and MFA",
    "minutes": 8,
    "platforms": [
      "mac",
      "windows"
    ],
    "required": [
      "security.lock"
    ],
    "summary": "Credentials and recovery material need a system, not sticky notes.",
    "lesson": "Use an appropriate password manager.\n\nUse unique passwords and MFA when available/required. Store recovery codes deliberately.\n\nNever put passwords, MFA seeds, private SSH keys, BitLocker/FileVault recovery keys, or access tokens into scripts, Git repositories, notebooks, shared documents, or chat.\n\nRCC Expedition is not a password vault and never requests these secrets.",
    "challenge": "Decide where passwords and recovery material will live before creating more accounts.",
    "hints": [],
    "mode": "manual"
  },
  {
    "id": "security.backup.win",
    "area": "Windows security",
    "title": "Back up Windows files — and test restore",
    "minutes": 14,
    "platforms": [
      "windows"
    ],
    "required": [
      "security.encrypt.win"
    ],
    "summary": "A backup is useful only when you can recover from it.",
    "lesson": "RCC project data should live in approved RCC storage, not only on the PC. The workstation still has documents, configuration, and keys that may need recovery.\n\nWindows File History can keep versions of personal files on an external drive or approved network location.\n\nBackup media containing sensitive material must be appropriately encrypted. On editions that support it, BitLocker To Go can encrypt removable drives. If your edition cannot provide an approved encrypted backup, use your group's approved backup solution instead of an unencrypted portable disk.\n\nTest restore: create a harmless file, back it up, delete it, and recover it.",
    "challenge": "Restore a harmless test file from your configured backup.",
    "hints": [
      "Do not finish merely because a backup destination exists."
    ],
    "mode": "manual",
    "external": [
      [
        "Microsoft: backup/recovery",
        "https://support.microsoft.com/en-us/windows/experience/backup-recovery/backup-restore-and-recovery-in-windows"
      ],
      [
        "Microsoft: BitLocker Drive Encryption",
        "https://support.microsoft.com/en-us/windows/security/encryption/bitlocker-drive-encryption"
      ]
    ]
  },
  {
    "id": "security.backup.mac",
    "area": "Mac security",
    "title": "Use encrypted Time Machine — and test restore",
    "minutes": 15,
    "platforms": [
      "mac"
    ],
    "required": [
      "security.encrypt.mac"
    ],
    "summary": "Configure encrypted backup and prove recovery works.",
    "lesson": "Connect the intended backup disk.\n\nOpen System Settings → General → Time Machine and add it. Enable encryption. Keep the backup password in your password/recovery system.\n\nCreate a harmless test file, let it be backed up, delete it, and restore it. The point of backup is recovery, not a green switch.",
    "challenge": "Restore a harmless test file from encrypted Time Machine.",
    "hints": [],
    "mode": "manual",
    "external": [
      [
        "Apple: Time Machine",
        "https://support.apple.com/guide/mac-help/back-up-files-mh35860/mac"
      ]
    ]
  },
  {
    "id": "network.internet",
    "area": "Connectivity",
    "title": "Use an Internet path, not the clinical network",
    "minutes": 7,
    "platforms": [
      "mac",
      "windows"
    ],
    "required": [
      "security.boundary"
    ],
    "summary": "RCC does not require a research workstation to become a clinical endpoint.",
    "lesson": "The workstation needs ordinary Internet connectivity to reach RCC.\n\nUse eduroam when you have the required university identity and it is available.\n\nWhere locally provided, Stiftungsnetz may be used as a temporary/semi-official bootstrap Internet route. This course relies only on its practical role as Internet access and asserts no undocumented security properties.\n\nAn approved guest Internet path or personal hotspot can solve temporary bootstrap needs.\n\nDo not use hospital/clinical VPN as an RCC connectivity workaround.",
    "challenge": "Obtain ordinary Internet connectivity without making the research workstation a clinical endpoint.",
    "hints": [],
    "mode": "manual"
  },
  {
    "id": "rcc.docs",
    "area": "RCC",
    "title": "ClusterDocs master is the RCC source of truth",
    "minutes": 4,
    "platforms": [
      "mac",
      "windows"
    ],
    "required": [
      "network.internet"
    ],
    "summary": "The course teaches skills; current ClusterDocs owns mutable RCC facts.",
    "lesson": "RCC infrastructure changes.\n\nCurrent ClusterDocs master — developed from the clusterdocs-ng line — is authoritative for current connection details, Slurm policy, storage, transfer methods, GPUs, and supported tools.\n\nRCC Expedition should not become a stale second copy. When exact syntax/policy can change, use current ClusterDocs.",
    "challenge": "Open ClusterDocs and locate current getting-started/connection material.",
    "hints": [],
    "mode": "manual",
    "external": [
      [
        "RCC ClusterDocs",
        "https://ikim-essen.github.io/ClusterDocs/"
      ]
    ]
  },
  {
    "id": "ssh.client.win",
    "area": "SSH",
    "title": "Make sure Windows OpenSSH Client is available",
    "minutes": 7,
    "platforms": [
      "windows"
    ],
    "required": [
      "rcc.docs",
      "security.patching.win"
    ],
    "summary": "Use Windows OpenSSH instead of installing random SSH utilities.",
    "lesson": "Open Windows Terminal or PowerShell and run:\n\nssh -V\n\nThe readiness panel checks ssh.exe and ssh-keygen.exe.\n\nIf OpenSSH Client is missing, add the Windows OpenSSH Client optional feature using current Microsoft instructions.\n\nYou do not need PuTTY solely to access RCC on a modern Windows 11 workstation.",
    "challenge": "Reach OpenSSH Client = PASS.",
    "hints": [
      "Re-open RCC Expedition from the Desktop launcher after installing it."
    ],
    "mode": "device",
    "deviceKey": "sshClient",
    "external": [
      [
        "Microsoft: OpenSSH for Windows",
        "https://learn.microsoft.com/en-us/windows-server/administration/openssh/openssh-overview"
      ]
    ]
  },
  {
    "id": "ssh.key.win",
    "area": "SSH",
    "title": "Generate a dedicated RCC SSH key on Windows",
    "minutes": 8,
    "platforms": [
      "windows"
    ],
    "required": [
      "ssh.client.win",
      "security.passwords"
    ],
    "summary": "The private half stays on your PC; only the public key is registered.",
    "lesson": "Open the Desktop folder “RCC Expedition Tools” and run:\n\n01 Create RCC SSH Key.cmd\n\nThe helper uses Windows OpenSSH ssh-keygen to create a dedicated Ed25519 key. Choose a passphrase.\n\nThe .pub file is public-key material. Never send the private key to an administrator or paste it into a website/email.",
    "challenge": "Reach RCC SSH key = PASS.",
    "hints": [],
    "mode": "device",
    "deviceKey": "sshKey",
    "external": [
      [
        "Microsoft: OpenSSH keys",
        "https://learn.microsoft.com/en-us/windows-server/administration/openssh/openssh_keymanagement"
      ]
    ]
  },
  {
    "id": "ssh.key.mac",
    "area": "SSH",
    "title": "Generate a dedicated RCC SSH key on Mac",
    "minutes": 8,
    "platforms": [
      "mac"
    ],
    "required": [
      "rcc.docs",
      "security.passwords"
    ],
    "summary": "The private half stays on your Mac; only the public key is registered.",
    "lesson": "Open “RCC Expedition Tools” on the Desktop and run:\n\n01 Create RCC SSH Key.command\n\nChoose a passphrase. Share/register only the .pub file. Never upload/email the private key.",
    "challenge": "Reach RCC SSH key = PASS.",
    "hints": [],
    "mode": "device",
    "deviceKey": "sshKey"
  },
  {
    "id": "ssh.configure",
    "area": "SSH",
    "title": "Configure the current RCC SSH path",
    "minutes": 12,
    "platforms": [
      "mac",
      "windows"
    ],
    "required": [
      "rcc.docs"
    ],
    "summary": "Use current ClusterDocs and stable aliases, not old worker hostnames.",
    "lesson": "Follow current ClusterDocs to register your public key and configure the supported RCC SSH path.\n\nDo not copy years-old wiki configuration if current ClusterDocs differs. Use ProxyJump/stable service aliases as documented.\n\nAvoid SSH agent forwarding as a general default.\n\nWhen configured, use the platform-specific “03 Test RCC SSH” helper. It runs one harmless fixed command and stores only PASS/FAIL locally.",
    "challenge": "Reach RCC SSH = PASS.",
    "hints": [
      "If access is not yet provisioned, mark Waiting and continue with workstation-security material."
    ],
    "mode": "device",
    "deviceKey": "rccSsh",
    "allowWaiting": true,
    "external": [
      [
        "RCC ClusterDocs",
        "https://ikim-essen.github.io/ClusterDocs/"
      ]
    ]
  },
  {
    "id": "linux.basics",
    "area": "Linux",
    "title": "Your first Linux challenge on RCC",
    "minutes": 15,
    "platforms": [
      "mac",
      "windows"
    ],
    "required": [
      "ssh.configure"
    ],
    "summary": "Learn pwd, ls, cd, find, grep, and paths by finding something.",
    "lesson": "RCC environments are Linux. Windows PowerShell is useful, but it is not the Linux shell you use on RCC.\n\nRun the platform-specific “02 Create Linux Practice” helper. It creates a tiny synthetic directory tree in your RCC home.\n\nThen connect to shellhost and find the file containing GATTACA.\n\nExperienced Linux user? Solve immediately. New user? Reveal hints.",
    "challenge": "On RCC, find the file containing GATTACA below ~/.rcc-expedition-practice/mystery and display the matching line.",
    "hints": [
      "Start with: cd ~/.rcc-expedition-practice/mystery ; pwd ; ls",
      "List files recursively: find . -type f",
      "Search recursively: grep -R GATTACA ."
    ],
    "mode": "manual",
    "challengeFirst": true
  },
  {
    "id": "rcc.shell-vs-compute",
    "area": "RCC",
    "title": "Shell/login hosts are not compute nodes",
    "minutes": 8,
    "platforms": [
      "mac",
      "windows"
    ],
    "required": [
      "linux.basics"
    ],
    "summary": "Prepare and submit interactively; ask Slurm for actual compute.",
    "lesson": "Use the shell/submission environment for lightweight preparation, small edits, job submission, and monitoring.\n\nCPU-heavy, memory-heavy, GPU, long-running, or interactive compute belongs in a Slurm allocation.\n\nThis is what allows shared resources to be scheduled fairly and observed/reproduced.",
    "challenge": "Identify the host you are on and use current ClusterDocs to find how to request an allocated compute resource.",
    "hints": [],
    "mode": "manual",
    "external": [
      [
        "RCC ClusterDocs",
        "https://ikim-essen.github.io/ClusterDocs/"
      ]
    ]
  },
  {
    "id": "rcc.slurm-first",
    "area": "Slurm",
    "title": "Submit your first Slurm job",
    "minutes": 15,
    "platforms": [
      "mac",
      "windows"
    ],
    "required": [
      "rcc.shell-vs-compute"
    ],
    "summary": "Run a tiny synthetic job through the scheduler.",
    "lesson": "Run the platform-specific “04 Run First Slurm Mission” helper.\n\nIt uses your own SSH client to create temporary synthetic work, submit one tiny Slurm job, inspect accounting, display the result, and remove temporary files.\n\nNo Academy server receives the job ID/result.\n\nThen learn the corresponding submission, queue, accounting, and cancellation commands from current ClusterDocs.",
    "challenge": "Reach RCC Slurm = PASS and explain what Slurm did.",
    "hints": [
      "If it fails, diagnose with current ClusterDocs rather than running the workload directly on shellhost."
    ],
    "mode": "device",
    "deviceKey": "rccSlurm",
    "external": [
      [
        "RCC ClusterDocs",
        "https://ikim-essen.github.io/ClusterDocs/"
      ]
    ]
  },
  {
    "id": "rcc.resources",
    "area": "Slurm",
    "title": "Request resources deliberately",
    "minutes": 12,
    "platforms": [
      "mac",
      "windows"
    ],
    "required": [
      "rcc.slurm-first"
    ],
    "summary": "CPU, memory, time, GPU, and partition choices are part of the experiment.",
    "lesson": "A good job requests enough resources to succeed without reserving huge amounts “just in case”.\n\nLearn current ClusterDocs syntax for wall time, CPU, memory, GPUs, and partition/constraints where relevant.\n\nInspect completed jobs and adjust future requests from evidence.",
    "challenge": "Submit a synthetic job with explicit time, CPU, and memory requests, then inspect accounting.",
    "hints": [
      "Put repeatable resource requests in versioned job/workflow configuration."
    ],
    "mode": "manual",
    "external": [
      [
        "RCC ClusterDocs",
        "https://ikim-essen.github.io/ClusterDocs/"
      ]
    ]
  },
  {
    "id": "rcc.storage",
    "area": "Storage",
    "title": "Know durable storage from local scratch",
    "minutes": 15,
    "platforms": [
      "mac",
      "windows"
    ],
    "required": [
      "rcc.slurm-first"
    ],
    "summary": "Shared durable data and node-local temporary I/O have different roles.",
    "lesson": "Use current ClusterDocs for the exact storage layout.\n\nGeneral pattern:\n1. approved durable input starts in project/group storage;\n2. stage only needed data to node-local scratch when useful;\n3. temporary/random-I/O-heavy work happens locally;\n4. validate results;\n5. return durable results to approved shared storage;\n6. local scratch is disposable.\n\nNever keep the only valuable copy in local scratch.",
    "challenge": "Complete the current efficient-I/O exercise or equivalent synthetic staging task.",
    "hints": [
      "Focus on storage roles, not one path name."
    ],
    "mode": "manual",
    "external": [
      [
        "RCC ClusterDocs",
        "https://ikim-essen.github.io/ClusterDocs/"
      ]
    ]
  },
  {
    "id": "rcc.data-boundary",
    "area": "Data",
    "title": "Do not improvise clinical-data transfer",
    "minutes": 12,
    "platforms": [
      "mac",
      "windows"
    ],
    "required": [
      "security.boundary",
      "rcc.storage"
    ],
    "summary": "Technical ability to copy a file is not permission to move governed data.",
    "lesson": "Use synthetic/non-sensitive material for onboarding.\n\nDo not use a laptop connected to clinical systems as an ad-hoc bridge into RCC.\n\nDirectly identifying patient data must not simply be copied into ordinary RCC project space because it is convenient. Clinical-origin data require the project's approved governance, de-identification/pseudonymisation, ingest, access, and transfer process.\n\nKnow the data class, approved research copy, allowed location, permitted users, and transfer route. If uncertain, stop before copying.",
    "challenge": "For your project, identify the approved data location and whom/process to ask before moving ambiguous clinical-origin data.",
    "hints": [
      "“scp works” is not a governance decision."
    ],
    "mode": "manual",
    "policy": true
  },
  {
    "id": "rcc.transfer",
    "area": "Data",
    "title": "Transfer data with the documented RCC method",
    "minutes": 10,
    "platforms": [
      "mac",
      "windows"
    ],
    "required": [
      "rcc.data-boundary"
    ],
    "summary": "Pick transfer tooling by size, location, and data class.",
    "lesson": "Use current ClusterDocs for supported transfer methods.\n\nSmall configuration files and large datasets have different needs. Prefer documented managed/server-to-server transfer for large data rather than routing large datasets through a laptop.\n\nUse checksums/integrity verification where appropriate.\n\nKeep data-governance decisions separate from transfer mechanics.",
    "challenge": "Using synthetic data, transfer a small file by the documented method and verify integrity.",
    "hints": [],
    "mode": "manual",
    "external": [
      [
        "RCC ClusterDocs",
        "https://ikim-essen.github.io/ClusterDocs/"
      ]
    ]
  },
  {
    "id": "repro.environments",
    "area": "Reproducibility",
    "title": "Use explicit software environments",
    "minutes": 12,
    "platforms": [
      "mac",
      "windows"
    ],
    "required": [
      "rcc.slurm-first"
    ],
    "summary": "Do not build analyses that only work because of years of shell history.",
    "lesson": "Follow current ClusterDocs for RCC-supported environment tooling.\n\nKeep project dependencies explicit. Prefer isolated environments instead of modifying system Python or installing arbitrary global packages.\n\nRecord versions sufficiently for later reproduction.",
    "challenge": "For a small synthetic project, identify the environment definition and how another user would recreate it.",
    "hints": [],
    "mode": "manual",
    "external": [
      [
        "RCC ClusterDocs",
        "https://ikim-essen.github.io/ClusterDocs/"
      ]
    ]
  },
  {
    "id": "repro.apptainer",
    "area": "Reproducibility",
    "title": "Use Apptainer for containerised RCC workloads",
    "minutes": 12,
    "platforms": [
      "mac",
      "windows"
    ],
    "required": [
      "repro.environments"
    ],
    "summary": "Use RCC's multi-user-safe container model rather than a Docker daemon on compute nodes.",
    "lesson": "Current ClusterDocs documents Apptainer as the RCC container mechanism.\n\nContainers package execution environments and can often consume Docker/OCI images without giving users a privileged Docker daemon on shared compute.\n\nLearn basic run/exec, bind mounts, and GPU integration.",
    "challenge": "Run a harmless container command through Apptainer on an allocated RCC resource.",
    "hints": [],
    "mode": "manual",
    "external": [
      [
        "RCC ClusterDocs: Apptainer",
        "https://ikim-essen.github.io/ClusterDocs/course/class-04-containers/"
      ]
    ]
  },
  {
    "id": "repro.workflows",
    "area": "Reproducibility",
    "title": "Use Snakemake or Nextflow for structured workflows",
    "minutes": 15,
    "platforms": [
      "mac",
      "windows"
    ],
    "required": [
      "repro.environments",
      "rcc.resources"
    ],
    "summary": "Let the workflow encode dependencies and Slurm schedule compute.",
    "lesson": "For multi-step analyses, encode dependencies/resources in a workflow rather than a long manual shell transcript.\n\nUse current RCC-supported Snakemake/Nextflow patterns. Dry-run/validate before large work and integrate with Slurm.\n\nKeep code, environments/containers, resource requests, and provenance versioned where practical.",
    "challenge": "Take a small training workflow, dry-run/validate it, and identify where Slurm resource requests live.",
    "hints": [],
    "mode": "manual",
    "external": [
      [
        "RCC ClusterDocs",
        "https://ikim-essen.github.io/ClusterDocs/"
      ]
    ]
  },
  {
    "id": "tools.vscode",
    "area": "Optional tools",
    "title": "Optional: use VS Code as an RCC client",
    "minutes": 8,
    "platforms": [
      "mac",
      "windows"
    ],
    "required": [
      "ssh.configure"
    ],
    "summary": "An IDE can make remote work comfortable without moving compute to the laptop.",
    "lesson": "If useful, install VS Code from the authoritative Microsoft source and use Remote SSH as documented by current ClusterDocs.\n\nThe IDE does not change resource policy: heavy work belongs in Slurm.\n\nBe deliberate about extensions and synchronization features for sensitive projects.",
    "challenge": "Optional: open a harmless training directory through Remote SSH.",
    "hints": [],
    "mode": "manual",
    "allowNA": true,
    "external": [
      [
        "RCC ClusterDocs: VS Code",
        "https://ikim-essen.github.io/ClusterDocs/reference/access-ssh-vscode/"
      ],
      [
        "Visual Studio Code",
        "https://code.visualstudio.com/"
      ]
    ]
  },
  {
    "id": "tools.jupyter",
    "area": "Optional tools",
    "title": "Optional: run Jupyter through Slurm and tunnelling",
    "minutes": 12,
    "platforms": [
      "mac",
      "windows"
    ],
    "required": [
      "rcc.slurm-first"
    ],
    "summary": "Notebook servers are compute and belong in scheduled allocations.",
    "lesson": "Follow current ClusterDocs.\n\nRun the notebook server through Slurm on an allocated worker. Access it through documented SSH tunnelling/remote-development methods.\n\nDo not expose notebook services directly to the Internet and do not run heavy notebooks on shellhost.",
    "challenge": "Optional: start a synthetic Jupyter session with the documented Slurm/tunnel model, then shut it down.",
    "hints": [],
    "mode": "manual",
    "allowNA": true,
    "external": [
      [
        "RCC ClusterDocs: Jupyter",
        "https://ikim-essen.github.io/ClusterDocs/course/class-09-python-notebooks/"
      ]
    ]
  },
  {
    "id": "summit.final",
    "area": "Final mission",
    "title": "Run one tiny RCC experiment end to end",
    "minutes": 30,
    "platforms": [
      "mac",
      "windows"
    ],
    "required": [
      "rcc.transfer",
      "repro.workflows"
    ],
    "summary": "Demonstrate the working model instead of taking a multiple-choice exam.",
    "lesson": "Complete a small synthetic analysis end to end:\n\n1. obtain training input;\n2. put durable input in the correct RCC project/group context;\n3. obtain workflow/code under version control;\n4. use an explicit environment/container;\n5. dry-run/validate;\n6. submit through Slurm with deliberate resources;\n7. use node-local scratch appropriately;\n8. validate output;\n9. return durable results to approved shared storage;\n10. record enough provenance to explain the result.\n\nThere is no central certification server. You should be able to explain and repeat the workflow.",
    "challenge": "Complete the synthetic run and explain why each step lives where it does.",
    "hints": [
      "Failure diagnosis is part of the exercise: use logs, Slurm accounting, and current ClusterDocs."
    ],
    "mode": "manual",
    "challengeFirst": true
  }
];
