#!/bin/bash
set -u
ROOT="$HOME/Library/Application Support/RCC Expedition"
OUT="$ROOT/course/generated/device-state.js"
STATE="$ROOT/mac/state/rcc-state.conf"
/bin/mkdir -p "$ROOT/course/generated" "$ROOT/mac/state"

disk="UNKNOWN"
case "$(/usr/bin/fdesetup status 2>/dev/null || true)" in
  *"FileVault is On"*) disk="PASS" ;;
  *"FileVault is Off"*) disk="FAIL" ;;
esac

gatekeeper="UNKNOWN"
case "$(/usr/sbin/spctl --status 2>/dev/null || true)" in
  *enabled*) gatekeeper="PASS" ;;
  *disabled*) gatekeeper="FAIL" ;;
esac

sshkey="NOT_SET"
if [ -f "$HOME/.ssh/id_ikim" ] && [ -f "$HOME/.ssh/id_ikim.pub" ]; then
  sshkey="PASS"
fi

rcc_ssh="NOT_TRIED"
rcc_slurm="NOT_TRIED"
if [ -f "$STATE" ]; then
  . "$STATE"
fi

ver="$(/usr/bin/sw_vers -productVersion 2>/dev/null || echo unknown)"
now="$(/bin/date '+%Y-%m-%d %H:%M:%S')"

cat > "$OUT" <<EOF
window.RCC_DEVICE_STATE = {
 generated: "$now",
 platform: "mac",
 version: "macOS $ver",
 checks: {
  supportedOS: "MANUAL_UPDATE_CHECK",
  diskEncryption: "$disk",
  platformSecurity: "$gatekeeper",
  defender: "NOT_APPLICABLE",
  firewall: "MANUAL_CHECK",
  secureBoot: "PLATFORM_MANAGED",
  sshClient: "PASS",
  sshKey: "$sshkey",
  rccSsh: "${rcc_ssh:-NOT_TRIED}",
  rccSlurm: "${rcc_slurm:-NOT_TRIED}"
 }
};
EOF
