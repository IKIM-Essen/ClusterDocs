#!/bin/bash
set -euo pipefail
echo "Removing RCC Expedition practice files only."
/usr/bin/ssh shellhost 'rm -rf "$HOME/.rcc-expedition-practice" "$HOME"/.rcc-expedition-slurm.*'
echo "Done."
