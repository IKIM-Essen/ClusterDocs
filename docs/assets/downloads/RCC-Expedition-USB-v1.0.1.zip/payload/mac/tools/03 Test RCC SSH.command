#!/bin/bash
set -euo pipefail
ROOT="$HOME/Library/Application Support/RCC Expedition"
STATE="$ROOT/mac/state/rcc-state.conf"
/bin/mkdir -p "$(dirname "$STATE")"
clear
cat <<'EOF'
TEST RCC SSH
============

Runs one harmless fixed command
on the SSH host alias shellhost.

Press Return to test.
Control-C cancels.
EOF
read -r _
old_slurm="NOT_TRIED"
if [ -f "$STATE" ]; then
  . "$STATE"
  old_slurm="${rcc_slurm:-NOT_TRIED}"
fi
rcc_ssh="FAIL"
if /usr/bin/ssh -o ConnectTimeout=15 shellhost 'printf RCC_EXPEDITION_OK' 2>/dev/null | /usr/bin/grep -q RCC_EXPEDITION_OK; then
 rcc_ssh="PASS"
 echo "PASS"
else
 echo "FAIL. Return to the course."
fi
cat > "$STATE" <<EOF
rcc_ssh=$rcc_ssh
rcc_slurm=$old_slurm
EOF
"$ROOT/mac/tools/rcc-doctor.sh" >/dev/null 2>&1 || true
/usr/bin/open "$ROOT/course/index.html"
