#!/bin/bash
set -euo pipefail
clear
cat <<'EOF'
LINUX PRACTICE
==============

Creates tiny synthetic practice files
in your RCC home directory.

Press Return to continue.
Control-C cancels.
EOF
read -r _
/usr/bin/ssh shellhost 'bash -s' <<'REMOTE'
set -e
root="$HOME/.rcc-expedition-practice/mystery"
rm -rf "$HOME/.rcc-expedition-practice"
mkdir -p "$root/alpha" "$root/beta/deeper" "$root/gamma"
printf 'nothing here\n' > "$root/alpha/readme.txt"
printf 'ACGTACGT\n' > "$root/beta/data.txt"
printf 'sequence=GATTACA\n' > "$root/beta/deeper/clue.txt"
printf 'almost=GATACA\n' > "$root/gamma/near-miss.txt"
REMOTE
echo "Practice files created."
echo "Return to the course."
