#!/bin/bash
set -euo pipefail
ROOT="$HOME/Library/Application Support/RCC Expedition"
STATE="$ROOT/mac/state/rcc-state.conf"
/bin/mkdir -p "$(dirname "$STATE")"
clear
cat <<'EOF'
FIRST SLURM JOB
===============

Submits one tiny synthetic job.
Temporary files are removed.

Press Return to start.
Control-C cancels.
EOF
read -r _
old_ssh="NOT_TRIED"
if [ -f "$STATE" ]; then
  . "$STATE"
  old_ssh="${rcc_ssh:-NOT_TRIED}"
fi
set +e
result="$(/usr/bin/ssh shellhost 'bash -s' <<'REMOTE'
set -euo pipefail
tmp="$(mktemp -d "$HOME/.rcc-expedition-slurm.XXXXXX")"
trap 'rm -rf "$tmp"' EXIT
cd "$tmp"
cat > job.sh <<'JOB'
#!/bin/bash
#SBATCH --job-name=rcc-expedition
#SBATCH --time=00:02:00
#SBATCH --mem=64M
#SBATCH --cpus-per-task=1
printf 'RCC_EXPEDITION_SLURM_OK\n'
hostname
JOB
jobid="$(sbatch --parsable job.sh)"
echo "Job: $jobid"
for i in $(seq 1 45); do
 state="$(sacct -n -X -j "$jobid" --format=State -P 2>/dev/null | head -1 | cut -d'|' -f1 | awk '{print $1}')"
 case "$state" in
  COMPLETED)
   cat "slurm-${jobid}.out"
   echo RCC_EXPEDITION_RESULT=PASS
   exit 0 ;;
  FAILED|CANCELLED|TIMEOUT|OUT_OF_MEMORY|NODE_FAIL)
   echo "State: $state"
   echo RCC_EXPEDITION_RESULT=FAIL
   exit 1 ;;
 esac
 sleep 2
done
echo RCC_EXPEDITION_RESULT=FAIL
exit 1
REMOTE
)"
rc=$?
set -e
printf '%s\n' "$result"
rcc_slurm="FAIL"
if [ "$rc" -eq 0 ] && printf '%s\n' "$result" | /usr/bin/grep -q RCC_EXPEDITION_RESULT=PASS; then
 rcc_slurm="PASS"
 echo "PASS"
fi
cat > "$STATE" <<EOF
rcc_ssh=$old_ssh
rcc_slurm=$rcc_slurm
EOF
"$ROOT/mac/tools/rcc-doctor.sh" >/dev/null 2>&1 || true
/usr/bin/open "$ROOT/course/index.html"
