#!/bin/bash
set -euo pipefail
ROOT="$HOME/Library/Application Support/RCC Expedition"
KEY="$HOME/.ssh/id_ikim"
clear
cat <<'EOF'
CREATE RCC SSH KEY
==================

The private key stays on this Mac.
Only the .pub file is registered.

Choose a passphrase when asked.

Press Return to continue.
Control-C cancels.
EOF
read -r _

if [ -e "$KEY" ] || [ -e "$KEY.pub" ]; then
 echo "Key already exists. Nothing changed."
 exit 1
fi
/bin/mkdir -p "$HOME/.ssh"
/bin/chmod 700 "$HOME/.ssh"
/usr/bin/ssh-keygen -t ed25519 -a 100 -f "$KEY"
/bin/chmod 600 "$KEY"
/bin/chmod 644 "$KEY.pub"
echo
echo "Public key:"
/bin/cat "$KEY.pub"
echo
echo "Never share:"
echo "$KEY"
"$ROOT/mac/tools/rcc-doctor.sh" >/dev/null 2>&1 || true
/usr/bin/open "$ROOT/course/index.html"
