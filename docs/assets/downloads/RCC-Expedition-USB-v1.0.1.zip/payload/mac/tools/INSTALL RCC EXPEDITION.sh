#!/bin/bash
set -euo pipefail
TOOLS="$(cd "$(dirname "$0")" && pwd)"
USB_ROOT="$(cd "$TOOLS/../../.." && pwd)"
ROOT="$HOME/Library/Application Support/RCC Expedition"
DESKTOP="$HOME/Desktop"

clear
cat <<'EOF'
RCC EXPEDITION
==============

Local and datensparsam.
No monitoring. No telemetry.

Do not use hospital/clinical VPN
as an RCC connectivity shortcut.

Press Return to install.
Control-C cancels.
EOF
read -r _

[ "$(/usr/bin/uname -s)" = "Darwin" ] || exit 1

echo "Checking USB..."
cd "$USB_ROOT"
/usr/bin/shasum -a 256 -c SHA256SUMS >/dev/null
echo "OK"

echo "Installing..."
/bin/rm -rf "$ROOT"
/bin/mkdir -p "$ROOT"
/usr/bin/ditto "$USB_ROOT/payload/course" "$ROOT/course"
/usr/bin/ditto "$USB_ROOT/payload/mac" "$ROOT/mac"

for f in "$ROOT"/mac/tools/*.sh "$ROOT"/mac/tools/*.command; do
  [ -e "$f" ] && /bin/chmod 700 "$f"
done

cat > "$DESKTOP/RCC Expedition.command" <<'LAUNCH'
#!/bin/bash
set -euo pipefail
ROOT="$HOME/Library/Application Support/RCC Expedition"
"$ROOT/mac/tools/rcc-doctor.sh" >/dev/null 2>&1 || true
/usr/bin/open "$ROOT/course/index.html"
LAUNCH
/bin/chmod 700 "$DESKTOP/RCC Expedition.command"

/bin/rm -rf "$DESKTOP/RCC Expedition Tools"
/bin/mkdir -p "$DESKTOP/RCC Expedition Tools"
for f in "$ROOT"/mac/tools/*.command; do
  [ -e "$f" ] || continue
  /bin/ln -s "$f" "$DESKTOP/RCC Expedition Tools/$(basename "$f")"
done

"$ROOT/mac/tools/rcc-doctor.sh" >/dev/null 2>&1 || true
/usr/bin/open "$ROOT/course/index.html"

echo
echo "Ready."
echo "Course opened in your browser."
echo "You may remove the USB."
